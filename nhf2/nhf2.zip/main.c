/**
 * @file main.c
 * @brief Egynelőre elég redundáns, de megtartottam ha később bővíteni akarom a projectet akkor innen lehet.
 * A példaként mellékelt osszetevok.txt és receptek.txt chatgpt által lettek generálva, nem mindig értelmes a tartlmuk.
 */
#include <stdio.h>
#include "menu.h"
#include "file_utils.h"

int main(void) {
    main_menu();
    return 0;
}

